window.addEventListener('load',function(e){
    var reg = document.getElementById("reg");
    
    
    reg.addEventListener('click', function(){
        window.location.href = "register.html";
    })
    
})